
public class Program_4 {
	static int count(int n, int c) {
		if(n == 0) {
			return c;
		}
		if(n % 10 == 0) {
			c++;
		}
		return count(n/10, c);
	}
	
	public static void main(String[] args) {
		
	}
	
}
