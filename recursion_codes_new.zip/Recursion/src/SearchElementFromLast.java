
public class SearchElementFromLast {
	
//	static int search(int arr[], int index, int e) {
//		if(arr.length - 1 == index) {
//			return -1;
//		}
//		int lastIndex = search(arr, index + 1, e);
//		if(lastIndex == -1) {
//			if(arr[index] == e) {
//				return index;
//			}
//			else {
//				return -1;
//			}
//		}
//		else if(lastIndex != -1) {
//			return lastIndex;
//		}
//		
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
