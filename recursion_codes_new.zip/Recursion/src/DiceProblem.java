import java.util.ArrayList;

public class DiceProblem {
	
	static ArrayList<String> dicePossibilities(int currentValue, int endValue) {
		if(currentValue == endValue) {
			ArrayList<String> t = new ArrayList<String>();
			t.add("");
			return t;
		}
		if(currentValue > endValue) {
			ArrayList<String> t = new ArrayList<String>();
			return t;
		}
		ArrayList<String> result = new ArrayList<String>();
		for(int dice = 1; dice <= 6; dice++) {
			int newValue = currentValue + dice;
			ArrayList<String> temp = dicePossibilities(newValue, endValue);
			for(String r : temp) {
				result.add(dice + r);
			}
		}
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(dicePossibilities(0, 3));
	}

}
