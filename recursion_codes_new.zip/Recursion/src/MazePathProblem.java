import java.util.ArrayList;

public class MazePathProblem {
	
	static ArrayList<String> getMazePath(int currentRow, int currentCol, int endRow, int endCol) {
//		Positive Base Case
		if(currentRow == endRow && currentCol == endCol) {
			ArrayList<String> temp = new ArrayList<String>();
			temp.add("");
			return temp;
		}
//		Negative Base Case
		if(currentRow > endRow || currentCol > endCol) {
			ArrayList<String> temp = new ArrayList<String>();
			return temp;
		}
		
		ArrayList<String> myResult = new ArrayList<String>();
		
//		Horizontal Path
		ArrayList<String> hResult = getMazePath(currentRow, currentCol + 1, endRow, endCol);
		for(String t : hResult) {
			myResult.add("H" + t);
		}
		
//		Vertical Path
		ArrayList<String> vResult = getMazePath(currentRow + 1, currentCol, endRow, endCol);
		for(String t : vResult) {
			myResult.add("V" + t);
		}
		
//		Diagonal Path
		ArrayList<String> dResult = getMazePath(currentRow + 1, currentCol + 1, endRow, endCol);
		for(String t : dResult) {
			myResult.add("D" + t);
		}
		
		return myResult;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(getMazePath(0,0,2,2));

	}

}
