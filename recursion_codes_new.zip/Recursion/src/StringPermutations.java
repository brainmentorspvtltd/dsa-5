import java.util.ArrayList;

public class StringPermutations {
	
	static ArrayList<String> perm(String str) {
		if(str.length() == 0) {
			ArrayList<String> emptyString = new ArrayList<String>();
			emptyString.add("");
			return emptyString;
		}
		char currentChar = str.charAt(0);
		String remainingStr = str.substring(1);
		
		ArrayList<String> temp = perm(remainingStr);
		ArrayList<String> result = new ArrayList<String>();
		for(String s : temp) {
			for(int i = 0; i <= s.length(); i++) {
				StringBuffer sb = new StringBuffer(s);
				sb.insert(i, currentChar);
				result.add(sb.toString());
			}
		}
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "abc";
		System.out.println(perm(str));
	}

}
