
public class PatternProgramP1 {
	
	static void printStar(int noOfStar) {
		if(noOfStar == 0) {
			return;
		}
		System.out.print("*");		// Processing Logic
		noOfStar = noOfStar - 1;	// Small Problem
		printStar(noOfStar);		// Recursive Call
	}
	
	static void printPattern(int rows, int currentRow) {
		if(rows == 0) {
			return;
		}
		printStar(currentRow);		// Print Stars in a row
		System.out.println();			// New Line
		printPattern(rows - 1, currentRow + 1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printPattern(5, 1);
	}

}
