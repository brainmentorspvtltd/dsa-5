import java.util.Stack;

public class ValidParentheses {
	
	static Stack<String> stack = new Stack<String>();
	static boolean validParentheses(String expression) {
		int n = expression.length();
		for(int i = 0; i < n; i++) {
			char singleChar = expression.charAt(i);
			if(singleChar == '(' || singleChar == '[' || singleChar == '{') {
				stack.push(String.valueOf(singleChar));
			}
			else if(stack.empty()) {
				return false;
			}
			switch(expression.charAt(i)) {
			case ')':
				String x = stack.peek();
				stack.pop();
				if(x.equals("]") || x.equals("}"))
					return false;
				break;
			case '}':
				x = stack.peek();
				stack.pop();
				if(x.equals("]") || x.equals(")"))
					return false;
				break;
			case ']':
				x = stack.peek();
				stack.pop();
				if(x.equals(")") || x.equals("}"))
					return false;
				break;
			}
		}
		return (stack.empty());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String expression = "[]()";
		System.out.println(validParentheses(expression));
				

	}

}
