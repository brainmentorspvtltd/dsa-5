import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class ReverseInString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "hello how are you";
		
//		Approach 1
//		s = s.trim();		// removing all leading and trailing spaces
//		List<String> wordList = Arrays.asList(s.split(" "));
//		Collections.reverse(wordList);
//		System.out.println(String.join(" ", wordList));
		
		Stack<String> stack = new Stack<String>();
		String words[] = s.split(" ");
		for(String word : words) {
			stack.push(word);
		}
		System.out.println(stack);
		while(!stack.isEmpty()) {
			System.out.print(stack.pop() + " ");
		}
		
	}

}
