
public class MaximiseArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int arr[] = {1,2,3,4,5,6,7,8};
		int arr[] = {2,5,4,3,6,8,1};
		int p = 1, q = 2, r = 3;
		int n = arr.length;
		int ans = Integer.MIN_VALUE;
//		for(int i = 0; i < n - 1; i++) {
//			for(int j = i + 1; j < n - 1; j++) {
//				for(int k = j + 1; k < n; k++) {
//					ans = Math.max(ans, p*arr[i] + q*arr[j] + r*arr[k]);
//				}
//			}
//		}
		
		int prefixMax[] = new int[n];
		prefixMax[0] = arr[0];
		for(int i = 1; i < n; i++) {
			prefixMax[i] = Math.max(prefixMax[i - 1], arr[i]);
		}
		
		System.out.println("Prefix Array...");
		for(int i : prefixMax) {
			System.out.print(i + ",");
		}
		
		System.out.println();
		
		for(int i = 1; i < n - 1; i++) {
			int expression = p * prefixMax[i - 1] + q * arr[i] + r * prefixMax[i + 1];
			ans = Math.max(ans, expression);
			System.out.println(prefixMax[i - 1] + "," + arr[i] + "," + prefixMax[i + 1]);
		}
		
		
		System.out.println(ans);
	}

}
