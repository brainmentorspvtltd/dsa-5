
public class SearchElement {
	
	static int search(int arr[], int index, int e) {
		if((arr.length) == index) {
			return -1;
		}
		if(arr[index] == e) {
			return index;
		}
		return search(arr, index+1, e);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {10,20,40,50,60,70};
		System.out.println(search(arr, 0, 20));
	}

}
