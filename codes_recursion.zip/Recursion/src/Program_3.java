
public class Program_3 {
	
	static void show(int n) {
		if(n <= 0) {
			return;
		}
		if(n % 2 != 0) {
			System.out.println(n);
		}
		show(n - 1);
		if(n % 2 == 0) {
			System.out.println(n);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 7;
		show(n);
//		O/P = 7,5,3,1,2,4,6

	}

}
