
public class RecursionIntro {

	static int fact(int n) {
		// base case / Termination condition
		if(n == 0) {
			return 1;
		}
		return n * fact(n-1);	// recurrence relation
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 5;
		fact(n);
	}

}
