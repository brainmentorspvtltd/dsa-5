public class SpiralMatrix {
	
	static void spiral(int arr[][], int m, int n) {
		int k = 0, l = 0;
		int i;
//		m - number of rows (ending row index)
//		n - number of cols (ending col index)
//		k - starting row index
//		l - starting col index
		
		while(k < m && l < n) {
			// print first row
			for(i = l; i < n; i++) {
				System.out.print(arr[k][i] + ",");
			}
			k++;
			
//			print the last col from remaining values
			for(i = k; i < m; i++) {
				System.out.print(arr[i][n - 1] + ",");
			}
			n--;
			
//			print last row from remaining values
			if(k < m) {
				for(i = n - 1; i >= l; i--) {
					System.out.print(arr[m - 1][i] + ",");
				}
				m--;
			}
			
//			print the first col from remaining values
			if(l < n) {
				for(i = m - 1; i >= k; i--) {
					System.out.print(arr[i][l] + ",");
				}
				l++;
			}
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[][] = {
				{1,2,3,4,5},
				{6,7,8,9,10},
				{11,12,13,14,15}
		};
		int r = 3;
		int c = 5;
		spiral(arr, r, c);
	}

}
