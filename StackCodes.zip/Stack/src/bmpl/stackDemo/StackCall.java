package bmpl.stackDemo;

public class StackCall {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack stack = new Stack(5);
		stack.push(10);
		stack.push(20);
		stack.push(30);
		
		stack.peek();
		
		stack.pop();
		stack.pop();
		stack.pop();
	}

}
