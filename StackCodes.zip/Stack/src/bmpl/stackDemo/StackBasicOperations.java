package bmpl.stackDemo;

import java.util.Stack;

public class StackBasicOperations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<String> stack = new Stack<String>();
		stack.push("Hello");
		stack.push("How");
		stack.push("Are");
		stack.push("You ?");
		
		System.out.println(stack.peek());
		
		System.out.println(stack.size());
		
		stack.pop();
		stack.pop();
		stack.pop();
		stack.pop();
		
		System.out.println(stack.isEmpty());

	}

}
