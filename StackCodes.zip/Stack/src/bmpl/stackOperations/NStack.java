package bmpl.stackOperations;

public class NStack {
	
	int arr[];	// Array to store actual content
	int top[];	// array of size n to store indexes of top elements of stacks
	int next[];	// array of size capacity to store next entry of all stacks
	int capacity;	// Number of elements
	int n;	// Number of stacks
	int free;	// store beginning index of free list
	
	public NStack(int capacity, int n) {
		this.capacity = capacity;
		this.n = n;
		
		arr = new int[capacity];
		next = new int[capacity];
		top = new int[n];
		
		// init next
		for(int i = 0; i < capacity - 1; i++) {
			next[i] = i + 1;
		}
		next[capacity - 1] = -1;
		
		// init top
		for(int i = 0; i < n; i++) {
			top[i] = -1;
		}
		
	}
	
	void push(int stackNumber, int element) {
		if(free == -1) {
			System.out.println("Stack is full...");
		}
		int index = free;
		free = next[index];
		next[index] = top[stackNumber];
		top[stackNumber] = index;
		arr[index] = element;
	}
	
	void pop(int stackNumber) {
		if(top[stackNumber] == -1) {
			System.out.println("Stack is Empty...");
			return;
		}
		int index = top[stackNumber];
		int element = arr[index];
		System.out.println("Pop :: " + element);
		top[stackNumber] = next[index];
		next[index] = free;
		free = index;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NStack nstack = new NStack(10, 3);
		nstack.push(2, 200);
		nstack.push(1, 100);
		nstack.push(0, 10);
		nstack.push(2, 201);
		nstack.push(1, 101);
		nstack.pop(2);
		nstack.push(0, 11);
		nstack.push(0, 12);
	}

}
