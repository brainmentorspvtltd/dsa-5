package bmpl.stackOperations;

import java.util.Stack;

public class HistogramProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int bars[] = {6,2,5,4,1,5,6};
		Stack<Integer> stack = new Stack<Integer>();
		stack.push(-1);		// Empty point
		int maxArea = 0;
//		Start traverse from left most bar
		for(int i = 0; i < bars.length; i++) {
//			checking if current bar is less than the stack top
//			checking stack is not empty && stack element is greater than the current bar
			while(stack.peek() != -1 && bars[stack.peek()] >= bars[i]) {
				int topE = stack.pop();		// current top element
				int rightIndex = i;			// rightmost element
				int leftIndex = stack.peek();	// top most element in stack
				maxArea = bars[topE] * ((rightIndex - leftIndex) - 1);
			}
			
//			if current bar is greater than the stack peek so keep pushing in stack
			stack.push(i);
		}
		// if stack is still not empty then use same formula
		while(stack.peek() != -1) {
			maxArea = Math.max(maxArea, bars[stack.pop()] * ((bars.length - stack.peek()) - 1));
		}
		System.out.println(maxArea);
	}

}
