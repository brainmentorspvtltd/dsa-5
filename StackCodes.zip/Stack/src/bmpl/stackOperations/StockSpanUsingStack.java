package bmpl.stackOperations;

import java.util.Stack;

public class StockSpanUsingStack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {60,10,20,40,35,30,50,70,65};
		Stack<Integer> stack = new Stack<Integer>();
		stack.push(0);
		System.out.print(1 + ",");
		for(int i = 1; i < arr.length; i++) {
			while(!stack.isEmpty() && arr[stack.peek()] <= arr[i]) {
				stack.pop();
			}
			int daySpan = stack.isEmpty() ? i + 1 : i - stack.peek();
			System.out.print(daySpan + ",");
			stack.push(i);
		}

	}

}
