package bmpl.stackOperations;

import java.util.ArrayList;

public class GenericStack<T> {
	
//	T arr[];
	ArrayList<T> arr;
	int capacity;
	int top;
	
	public GenericStack(int capacity) {
		this.capacity = capacity;
		top = -1;
//		arr = new T[capacity];
		arr = new ArrayList<T>(capacity);
	}
	
	void push(T element) {
		// check if stack is not full
		if(getSize() == capacity - 1) {
			throw new RuntimeException("Stack is full...");
		}
		System.out.println("Push :: " + element);
		top++;
		arr.add(top, element);
	}
	
	T pop() {
		// check if stack is empty
		if(isEmpty()) {
			throw new RuntimeException("Stack is Empty...");
		}
//		int element = arr[top];
		T element = arr.remove(top);
		System.out.println("Pop :: " + element);
		top--;
		return element;
	}
	
	void peek() {
//		System.out.println(arr[top]);
		for(int i = top; i >= 0; i--) {
			System.out.println(arr.get(i));
		}
//		return top;
	}
	
	boolean isEmpty() {
		return (top == -1);
	}
	
	int getSize() {
		return top;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
