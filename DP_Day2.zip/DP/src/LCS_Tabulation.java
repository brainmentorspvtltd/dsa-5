public class LCS_Tabulation {
	
	static int lcsTabulation(String first, String second, int m, int n) {
		int matrix[][] = new int[m+1][n+1];
		for(int i = 0; i <= m; i++) {
			for(int j = 0; j <= n; j++) {
				if(i == 0 || j == 0) {
					matrix[i][j] = 0;
				}
				else if (first.charAt(i - 1) == second.charAt(j - 1)){
					matrix[i][j] = matrix[i - 1][j - 1] + 1;
				}
				else {
					matrix[i][j] = Math.max(matrix[i - 1][j], matrix[i][j - 1]);
				}
			}
		}
		return matrix[m][n];
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abcdgh";
		String s2 = "aedfhr";
		int m = s1.length();
		int n = s2.length();
		int result = lcsTabulation(s1, s2, m, n);
		System.out.println(result);

	}

}
