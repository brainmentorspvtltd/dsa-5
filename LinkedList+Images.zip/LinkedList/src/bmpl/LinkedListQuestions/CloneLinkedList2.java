package bmpl.LinkedListQuestions;

public class CloneLinkedList2 {
	
	static NodeDLL clone(NodeDLL start) {
		NodeDLL next, temp;
//		Step 1 : create new node
		for(NodeDLL current = start; current != null;) {
			next = current.next;
			current.next = new NodeDLL(current.data);
			current.next.next = next;
			current = next;
		}
		
		for(NodeDLL current = start; current != null; current = current.next.next) {
//			Step 2
			current.next.random = (current.random != null) ? (current.random.next) : null;
		}
		
		NodeDLL original = start.next, copy = start.next;
		temp = copy;
//		Step 3
		while(original != null && copy != null) {
			original.next = original.next != null ? original.next.next : original.next;
			copy.next = copy.next != null ? copy.next.next : copy.next;
			original = original.next;
			copy = copy.next;
		}
		
		return temp;
		
	}
	
	static void print(NodeDLL start) {
		NodeDLL temp = start;
		while(temp != null) {
			System.out.println(temp.data + " :: " + temp.random.data);
			temp = temp.next;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		NodeDLL start = new NodeDLL(10);
		start.next = new NodeDLL(20);
		start.next.next = new NodeDLL(30);
		start.next.next.next = new NodeDLL(20);
		start.next.next.next.next = new NodeDLL(40);
		
		start.random = start.next.next;
		start.next.random = start.next;
		start.next.next.random = start.next.next.next;
		start.next.next.next.random = start.next.next.next.next;
		start.next.next.next.next.random = start;
		
		print(start);
		NodeDLL cloneList = clone(start);
		print(cloneList);

	}

}
