package bmpl.LinkedListQuestions;

import java.util.HashMap;

class NodeDLL {
	int data;
	NodeDLL next, random;
	NodeDLL(int data) {
		this.data = data;
		next = random = null;
	}
}

public class CloneLinkedListHashing {
	
	static NodeDLL clone(NodeDLL start) {
		HashMap<NodeDLL, NodeDLL> map = new HashMap<NodeDLL, NodeDLL>();
		for(NodeDLL current = start; current != null; current=current.next) {
			map.put(current, new NodeDLL(current.data));
		}
		
		for(NodeDLL current = start; current != null; current = current.next) {
			NodeDLL cloneCurrent = map.get(current);
			cloneCurrent.next = map.get(current.next);
			cloneCurrent.random = map.get(current.random);
		}
		NodeDLL head2 = map.get(start);
		return head2;
		
	}
	
	static void print(NodeDLL start) {
		NodeDLL temp = start;
		while(temp != null) {
			System.out.println(temp.data + " :: " + temp.random.data);
			temp = temp.next;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NodeDLL start = new NodeDLL(10);
		start.next = new NodeDLL(20);
		start.next.next = new NodeDLL(30);
		start.next.next.next = new NodeDLL(20);
		start.next.next.next.next = new NodeDLL(40);
		
		start.random = start.next.next;
		start.next.random = start.next;
		start.next.next.random = start.next.next.next;
		start.next.next.next.random = start.next.next.next.next;
		start.next.next.next.next.random = start;
		
		print(start);
		NodeDLL cloneList = clone(start);
		print(cloneList);
	}

}
