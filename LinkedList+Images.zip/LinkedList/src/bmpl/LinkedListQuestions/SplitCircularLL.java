package bmpl.LinkedListQuestions;

public class SplitCircularLL {
	
	Node start;
	Node tail;
	
	void splitCircular() {
		Node fast = start;
		Node slow = start;
		if(start == null) {
			System.out.println("Empty List...");
			return;
		}
		while(fast.next != start && fast.next.next != start) {
			fast = fast.next.next;
			slow = slow.next;
		}
		if(fast.next.next == start) {
			fast = fast.next;
		}
		
		Node start1 = start;
		Node start2 = null;
		if(start.next != start) {
			start2 = slow.next;
		}
		fast.next = slow.next;
		slow.next = start;
		System.out.println("After 2 halfs...");
		print(start1);
		print(start2);
	}
	
	void print(Node head) {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
