public class EditDistanceRec {
	
	static int ed(String first, String second, int m, int n) {
		// if first string is empty, the only option is to insert all
		// characters of second string into first
		if(m == 0) {
			return n;
		}
		
		// if second string is empty, the only option is to remove all
		// characters of first string
		if (n == 0) {
			return m;
		}
		
		if(first.charAt(m - 1) == second.charAt(n - 1)) {
			return ed(first, second, m - 1, n - 1);
		}
		
		int insert = ed(first, second, m, n-1);
		int delete = ed(first, second, m-1, n);
		int replace = ed(first, second, m-1, n-1);
		int min = Math.min(insert, delete);
		return 1 + Math.min(replace, min);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String first = "sunday";
		String second = "saturday";
		int m = first.length();
		int n = second.length();
		System.out.println(ed(first, second, m, n));

	}

}
