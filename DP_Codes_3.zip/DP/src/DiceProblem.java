public class DiceProblem {
	
	static int countWays(int currentValue, int endValue) {
		if(currentValue == endValue) {
			return 1;
		}
		if(currentValue > endValue) {
			return 0;
		}
		int count = 0;
		for(int dice = 1; dice <= 6; dice++) {
			count = count + countWays(currentValue + dice, endValue);
		}
		return count;
	}
	
	static int countWaysWithDP(int currentValue, int endValue, int [] cache) {
		if(currentValue == endValue) {
			return 1;
		}
		if(currentValue > endValue) {
			return 0;
		}
		if(cache[currentValue] != 0) {
			return cache[currentValue];
		}
		int count = 0;
		for(int dice = 1; dice <= 6; dice++) {
			count = count + countWaysWithDP(currentValue + dice, endValue, cache);
		}
		cache[currentValue] = count;
		return count;
	}
	
	static int tabulation(int start, int end) {
		int cache[] = new int[end + 1];
		cache[end] = 1;
		for(int i = end - 1; i >= 0; i--) {
			int count = 0;
			for(int dice = 1; dice <= 6 && dice + i < cache.length; dice++) {
				count += cache[dice + i];
			}
			cache[i] = count;
		}
		return cache[start];
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Using simple recursion, Without DP");
//		long startTime = System.currentTimeMillis();
//		int n = 30;
//		int result = 0;
//		result = countWays(0, n);
//		long endTime = System.currentTimeMillis();
//		long totalTime = endTime - startTime;
//		System.out.println("Total Time Taken is : " + totalTime);
//		System.out.println("Ways are : " + result);
//		
//		System.out.println("======================");
//		
//		System.out.println("Using DP : Memoization");
//		startTime = System.currentTimeMillis();
//		result = countWaysWithDP(0, n, new int[n + 1]);
//		endTime = System.currentTimeMillis();
//		totalTime = endTime - startTime;
//		System.out.println("Total Time Taken is : " + totalTime);
//		System.out.println("Ways are : " + result);
		
		System.out.println("======================");
		
		System.out.println("Using DP : Tabulation");
		long startTime = System.currentTimeMillis();
		int result = tabulation(0, 30);
		long endTime = System.currentTimeMillis();
		long totalTime = endTime - startTime;
		System.out.println("Total Time Taken is : " + totalTime);
		System.out.println("Ways are : " + result);

	}

}
