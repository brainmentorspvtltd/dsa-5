public class LCS_Memoization {
	
	static int lcsMemo(String X, String Y, int m, int n, int dp[][]) {
		if(m == 0 || n == 0) {
			return 0;
		}
		
		if(dp[m - 1][n - 1] != 0) {
			return dp[m - 1][n - 1];
		}
		
		if(X.charAt(m - 1) == Y.charAt(n - 1)) {
			dp[m - 1][n - 1] = 1 + lcsMemo(X, Y, m-1, n-1, dp);
		}
		else {
			dp[m - 1][n - 1] = Math.max(
					lcsMemo(X, Y, m-1, n, dp),
					lcsMemo(X, Y, m, n-1, dp));
		}
		return dp[m-1][n-1];
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abcdgh";
		String s2 = "aedfhr";
		int m = s1.length();
		int n = s2.length();
		int cache[][] = new int[m][n];
		int result = lcsMemo(s1, s2, m, n, cache);
		System.out.println(result);

	}

}
