public class MinCostPathRecursive {
	
	static int minCost(int cost[][], int m, int n) {
		if(n < 0 || m < 0) {
			return Integer.MAX_VALUE;
		}
		else if(m == 0 && n == 0) {
			return cost[m][n];
		}
		else {
			return cost[m][n] + Math.min(Math.min(
					minCost(cost, m - 1, n - 1),
					minCost(cost, m - 1, n)
					), minCost(cost, m, n - 1));
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int matrix[][] = {
				{2,0,6},
				{3,1,7},
				{4,5,9}
		};
		System.out.println(minCost(matrix, 2, 2));

	}

}
