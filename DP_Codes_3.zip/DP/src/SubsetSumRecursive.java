public class SubsetSumRecursive {
	
	static boolean subSet(int arr[], int sum, int n) {
		// no items left, or sum becomes negative
		if(n < 0 || sum < 0) {
			return false;
		}

		// subset found
		if(sum == 0) {
			return true;
		}
		
		return subSet(arr, sum - arr[n], n - 1) || subSet(arr, sum, n - 1);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {1,2,4,6,5};
		System.out.println(subSet(arr, 80, arr.length - 1));

	}

}
