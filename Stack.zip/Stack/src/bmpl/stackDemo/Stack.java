package bmpl.stackDemo;

public class Stack {
	
	int arr[];
	int capacity;
	int top;
	public Stack(int capacity) {
		this.capacity = capacity;
		top = -1;
		arr = new int[capacity];
	}
	
	void push(int element) {
		// check if stack is not full
		if(getSize() == capacity - 1) {
			throw new RuntimeException("Stack is full...");
		}
		System.out.println("Push :: " + element);
		top++;
		arr[top] = element;
	}
	
	int pop() {
		// check if stack is empty
		if(isEmpty()) {
			throw new RuntimeException("Stack is Empty...");
		}
		int element = arr[top];
		System.out.println("Pop :: " + element);
		top--;
		return element;
	}
	
	void peek() {
		System.out.println(arr[top]);
//		return top;
	}
	
	boolean isEmpty() {
		return (top == -1);
	}
	
	int getSize() {
		return top;
	}

}
