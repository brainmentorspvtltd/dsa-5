package bmpl.stackOperations;

public class StackCall {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenericStack<String> strStack = new GenericStack<String>(5);
//		GenericStack<Integer> intStack = new GenericStack<Integer>(5);
		
		strStack.push("Hello");
		strStack.push("How");
		strStack.push("are");
		strStack.push("you");
		strStack.push("?");
		
		strStack.peek();
		
		strStack.pop();
		strStack.pop();
		strStack.pop();
		strStack.pop();
		strStack.pop();
		
	}

}
